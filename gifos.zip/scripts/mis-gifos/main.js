import * as nocturno from "./nocturno.js"
import * as hamburguesa from "./hamburguesa.js";
import * as creados from "./creados.js"
import * as trendingGif from "./trendingGif.js"